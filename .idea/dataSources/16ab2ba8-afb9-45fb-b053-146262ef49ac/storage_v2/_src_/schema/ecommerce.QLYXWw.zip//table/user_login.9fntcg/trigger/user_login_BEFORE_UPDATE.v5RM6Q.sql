create definer = ECE651@`%` trigger user_login_BEFORE_UPDATE
    before update
    on user_login
    for each row
BEGIN
	SET new.updated = now();
END;

