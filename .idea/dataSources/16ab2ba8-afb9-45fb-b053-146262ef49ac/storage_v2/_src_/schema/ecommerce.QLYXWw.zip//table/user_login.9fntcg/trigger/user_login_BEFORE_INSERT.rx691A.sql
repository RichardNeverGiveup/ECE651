create definer = ECE651@`%` trigger user_login_BEFORE_INSERT
    before insert
    on user_login
    for each row
BEGIN
	SET new.created = now();
END;

